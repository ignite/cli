package keeper

import (
	"github.com/test/mars/x/mars/types"
)

var _ types.QueryServer = Keeper{}
