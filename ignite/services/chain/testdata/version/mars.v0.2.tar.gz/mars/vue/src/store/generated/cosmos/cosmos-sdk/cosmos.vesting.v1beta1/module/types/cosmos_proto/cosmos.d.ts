export declare const protobufPackage = "cosmos_proto";
