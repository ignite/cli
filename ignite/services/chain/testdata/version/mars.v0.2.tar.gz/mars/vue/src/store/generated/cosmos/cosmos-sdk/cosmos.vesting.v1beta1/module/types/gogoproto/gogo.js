/* eslint-disable */
export const protobufPackage = 'gogoproto';
