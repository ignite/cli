declare const _default: {
    CosmosCosmosSdkCosmosBankV1Beta1: (store: any) => void;
    CosmosCosmosSdkCosmosBaseAbciV1Beta1: (store: any) => void;
    CosmosCosmosSdkCosmosBaseV1Beta1: (store: any) => void;
    CosmosCosmosSdkCosmosCrisisV1Beta1: (store: any) => void;
    CosmosCosmosSdkCosmosDistributionV1Beta1: (store: any) => void;
    CosmosCosmosSdkCosmosEvidenceV1Beta1: (store: any) => void;
    CosmosCosmosSdkCosmosGovV1Beta1: (store: any) => void;
    CosmosCosmosSdkCosmosSlashingV1Beta1: (store: any) => void;
    CosmosCosmosSdkCosmosStakingV1Beta1: (store: any) => void;
    CosmosCosmosSdkCosmosVestingV1Beta1: (store: any) => void;
    CosmosCosmosSdkIbcApplicationsTransferV1: (store: any) => void;
    CosmosCosmosSdkIbcCoreChannelV1: (store: any) => void;
    CosmosCosmosSdkIbcCoreClientV1: (store: any) => void;
    CosmosCosmosSdkIbcCoreConnectionV1: (store: any) => void;
};
export default _default;
